/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    //program for fibonacci series
    int n,a=0,b=1,i,c;
    printf("enter the no. of terms:");
    scanf("%d",&n);
    if(n==1)
    {
        printf("%d",a);
    }
    else if(n==2)
    {
        printf("%d%d",a,b);
    }
    else
    {
        printf("%d\n%d\n",a,b);
        for(i=3;i<=n;i++)
        {
            c=a+b;
            printf("%d\n",c);
            a=b;
            b=c;
        }
    }

    return 0;
}